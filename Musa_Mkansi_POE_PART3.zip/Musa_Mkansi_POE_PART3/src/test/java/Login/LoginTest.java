/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Login;


import com.mycompany.musa_mkansi_poe_part3.Login;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class LoginTest {

    @Test
    public void testUserNameCorrectlyFormatted() {
        Login login = new Login();
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testUserNameIncorrectlyFormatted() {
        Login login = new Login();
        assertFalse(login.checkUserName("kyle!!!!"));
    }

    @Test
    public void testPasswordComplexityCorrect() {
        Login login = new Login();
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordComplexityIncorrect() {
        Login login = new Login();
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneNumberCorrect() {
        Login login = new Login();
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCellPhoneNumberIncorrect() {
        Login login = new Login();
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testRegisterUserSuccess() {
        Login login = new Login();
        String expected = "User has been registered successfully.";
        String actual = login.registerUser("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27831234567");
        assertEquals(expected, actual);
    }

    @Test
    public void testLoginUserSuccess() {
        Login login = new Login();
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27831234567");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginUserFail() {
        Login login = new Login();
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27831234567");
        assertFalse(login.loginUser("kyl_1", "wrongPass123!"));
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        Login login = new Login();
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27831234567");
        String expected = "Welcome Kyle Smith, it is great to see you again.";
        String actual = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!");
        assertEquals(expected, actual);
    }

    @Test
    public void testReturnLoginStatusFail() {
        Login login = new Login();
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&&sec@ke99!", "+27831234567");
        String expected = "Username or password incorrect, please try again.";
        String actual = login.returnLoginStatus("kyl_1", "wrongPass123!");
        assertEquals(expected, actual);
    }
}