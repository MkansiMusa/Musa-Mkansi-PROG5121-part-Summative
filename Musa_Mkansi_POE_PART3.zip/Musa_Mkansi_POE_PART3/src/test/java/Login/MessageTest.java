package Login;
 
// Import Message class

import com.mycompany.musa_mkansi_poe_part3.Message;
 
// Import test methods

import static org.junit.jupiter.api.Assertions.*;
 
// Import JUnit test annotation

import org.junit.jupiter.api.Test;
 
public class MessageTest {
 
    // Test if message length is correct

    @Test

    public void testMessageLengthSuccess() {
        // Create message object
        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );
        // Check message length
        assertEquals(
                "Message ready to send.",
                msg.checkMessageLength()
        );
    }
    // Test valid phone number
    @Test
    public void testRecipientNumberSuccess() {
        // Create message object
        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );
        // Check phone number
        assertEquals(
                "Cell phone number successfully captured.",
                msg.checkRecipientCell()
        );
    }
    // Test invalid phone number
    @Test
    public void testRecipientNumberFail() {
        // Create message object
        Message msg = new Message(
                0,
                "0812345678",
                "Hi Keegan, did you receive the payment?"
        );
        // Check invalid number
        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                msg.checkRecipientCell()
        );
    }
    // Test message ID
    @Test
    public void testMessageIDCreated() {
        // Create message object
        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );
        // Check message ID
        assertTrue(msg.checkMessageID());
    }
    // Test message hash
    @Test
    public void testMessageHashCorrect() {
        // Create message object
        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );
        // Get hash
        String hash = msg.getMessageHash();
        // Check hash format
        assertTrue(hash.contains(":0:HITONIGHT?")
        );
    }
    // Test send message option
    @Test
    public void testMessageSentSuccessfully() {
        // Create message object
        Message msg = new Message(
                0,
                "+27718693002",
                "Test Message"
        );
        // Check send option
        assertEquals(
                "Message successfully sent.",
                msg.sentMessage(1)
        );
    }
    // Test disregard option
    @Test
    public void testMessageDisregarded() {
        // Create message object
        Message msg = new Message(
                0,
                "+27718693002",
                "Test Message"
        );
        // Check disregard option
        assertEquals(
                "Press 0 to delete the message.",
                msg.sentMessage(2)
        );
    }
    // Test store option
    @Test
    public void testMessageStored() 
    {
        // Create message object

        Message msg = new Message(
                0,
                "+27718693002",
                "Test Message"
        );
        // Check store option
        assertEquals(
                "Message successfully stored.",
                msg.sentMessage(3)
        );
    }
}
 