package Login;

// Import Message class
import com.mycompany.musa_mkansi_poe_part3.Message;
import com.mycompany.musa_mkansi_poe_part3.StoredMessages;

// Import JUnit assertions
import static org.junit.jupiter.api.Assertions.*;

// Import JUnit test annotation
import org.junit.jupiter.api.Test;

/**
 * Unit tests for StoredMessages class.
 */
public class StoredMessagesTest {

    // Test that sent messages are correctly added to the sentMessages array
    @Test
    public void testSentMessagesArray() {

        // Clear arrays before testing
        StoredMessages.clearAll();

        // Create a message object
        Message msg = new Message(
                1,
                "+27718693002",
                "Did you get the cake?"
        );

        // Add message to sent messages array
        StoredMessages.addSentMessage(msg);

        // Verify array contains one message
        assertEquals(
                1,
                StoredMessages.sentMessages.size()
        );

        // Verify correct message was stored
        assertEquals(
                "Did you get the cake?",
                StoredMessages.sentMessages.get(0).getMessage()
        );
    }

    // Test that the longest stored message is correctly identified
    @Test
    public void testLongestStoredMessage() {

        // Clear arrays before testing
        StoredMessages.clearAll();

        // Create test messages
        Message msg1 = new Message(
                1,
                "+27718693002",
                "Short message"
        );

        Message msg2 = new Message(
                2,
                "+27831234567",
                "This is the longest message in this test"
        );

        // Store messages
        StoredMessages.addStoredMessage(msg1);
        StoredMessages.addStoredMessage(msg2);

        // Verify longest message is returned
        assertEquals(
                "This is the longest message in this test",
                StoredMessages.displayLongestStoredMessage()
        );
    }

    // Test searching for a message using Message ID
    @Test
    public void testSearchByMessageID() {

        // Clear arrays before testing
        StoredMessages.clearAll();

        // Create and store a message
        Message msg = new Message(
                1,
                "+27718693002",
                "Please call me later"
        );

        StoredMessages.addStoredMessage(msg);

        // Search using generated Message ID
        String result = StoredMessages.searchByMessageID(
                msg.getMessageID()
        );

        // Verify recipient exists in result
        assertTrue(
                result.contains("+27718693002")
        );

        // Verify message exists in result
        assertTrue(
                result.contains("Please call me later")
        );
    }

    // Test searching for messages by recipient number
    @Test
    public void testSearchByRecipient() {

        // Clear arrays before testing
        StoredMessages.clearAll();

        // Create messages for same recipient
        Message msg1 = new Message(
                1,
                "+27718693002",
                "First message"
        );

        Message msg2 = new Message(
                2,
                "+27718693002",
                "Second message"
        );

        // Store messages
        StoredMessages.addStoredMessage(msg1);
        StoredMessages.addStoredMessage(msg2);

        // Search by recipient
        String result = StoredMessages.searchByRecipient(
                "+27718693002"
        );

        // Verify both messages are returned
        assertTrue(result.contains("First message"));
        assertTrue(result.contains("Second message"));
    }

    // Test deleting a stored message using its hash value
    @Test
    public void testDeleteByHash() {

        // Clear arrays before testing
        StoredMessages.clearAll();

        // Create and store message
        Message msg = new Message(
                1,
                "+27718693002",
                "Delete this message"
        );

        StoredMessages.addStoredMessage(msg);

        // Delete using generated hash
        String result = StoredMessages.deleteByHash(
                msg.getMessageHash()
        );

        // Verify delete message appears
        assertTrue(
                result.contains("successfully deleted")
        );

        // Verify message was removed
        assertEquals(
                0,
                StoredMessages.storedMessages.size()
        );
    }

    // Test displaying full stored messages report
    @Test
    public void testDisplayReport() {

        // Clear arrays before testing
        StoredMessages.clearAll();

        // Create and store a message
        Message msg = new Message(
                1,
                "+27718693002",
                "Report test message"
        );

        StoredMessages.addStoredMessage(msg);

        // Generate report
        String report = StoredMessages.displayReport();

        // Verify report contains hash
        assertTrue(
                report.contains(msg.getMessageHash())
        );

        // Verify report contains message ID
        assertTrue(
                report.contains(msg.getMessageID())
        );

        // Verify report contains recipient
        assertTrue(
                report.contains("+27718693002")
        );

        // Verify report contains message text
        assertTrue(
                report.contains("Report test message")
        );
    }
}