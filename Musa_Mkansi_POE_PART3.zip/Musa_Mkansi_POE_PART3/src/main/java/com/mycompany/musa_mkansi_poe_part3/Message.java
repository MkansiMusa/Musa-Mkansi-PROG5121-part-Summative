package com.mycompany.musa_mkansi_poe_part3;

import java.util.Random;

/**
 * Message class creates and manages QuickChat messages.
 */
public class Message {

    // Unique message ID
    private String messageID;

    // Number of messages sent
    private int numMessagesSent;

    // Recipient cellphone number
    private String recipient;

    // Message text
    private String message;

    // Message hash
    private String messageHash;

    // Constructor creates a message object
    public Message(int numMessagesSent, String recipient, String message) {
        this.messageID = generateMessageID();
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    // Generates a random 10 digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        String id = "";

        for (int i = 0; i < 10; i++) {
            id += rand.nextInt(10);
        }

        return id;
    }

    // Checks that the message ID is not more than 10 characters
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Validates recipient cellphone number
    public String checkRecipientCell() {
        if (recipient.length() == 12 && recipient.startsWith("+27")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Checks that the message is not longer than 250 characters
    public String checkMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int extra = message.length() - 250;
            return "Message exceeds 250 characters by " + extra + "; please reduce the size.";
        }
    }

    // Creates the message hash using ID, message number, first word and last word
    public String createMessageHash() {
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String firstTwoDigits = messageID.substring(0, 2);

        return (firstTwoDigits + ":" + numMessagesSent + ":" + firstWord + lastWord).toUpperCase();
    }

    // Returns message action result based on user option
    public String sentMessage(int option) {
        if (option == 1) {
            return "Message successfully sent.";
        } else if (option == 2) {
            return "Press 0 to delete the message.";
        } else if (option == 3) {
            return "Message successfully stored.";
        } else {
            return "Invalid option selected.";
        }
    }

    // Prints message details
    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    // Returns total messages sent
    public int returnTotalMessages() {
        return numMessagesSent;
    }

    // Getter for message ID
    public String getMessageID() {
        return messageID;
    }

    // Getter for message hash
    public String getMessageHash() {
        return messageHash;
    }

    // Getter for recipient
    public String getRecipient() {
        return recipient;
    }

    // Getter for message
    public String getMessage() {
        return message;
    }
}