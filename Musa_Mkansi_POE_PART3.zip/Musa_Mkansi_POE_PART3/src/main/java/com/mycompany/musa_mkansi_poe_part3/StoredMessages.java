package com.mycompany.musa_mkansi_poe_part3;

import java.util.ArrayList;

/**
 * StoredMessages class manages arrays for sent, stored and disregarded messages.
 */
public class StoredMessages {

    // ArrayLists used to store different message categories
    public static ArrayList<Message> sentMessages = new ArrayList<>();
    public static ArrayList<Message> disregardedMessages = new ArrayList<>();
    public static ArrayList<Message> storedMessages = new ArrayList<>();

    // ArrayLists used to store message hashes and IDs
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();

    // Adds a message to the sent messages array
    public static void addSentMessage(Message msg) {
        sentMessages.add(msg);
        messageHashes.add(msg.getMessageHash());
        messageIDs.add(msg.getMessageID());
    }

    // Adds a message to the disregarded messages array
    public static void addDisregardedMessage(Message msg) {
        disregardedMessages.add(msg);
    }

    // Adds a message to the stored messages array
    public static void addStoredMessage(Message msg) {
        storedMessages.add(msg);
        messageHashes.add(msg.getMessageHash());
        messageIDs.add(msg.getMessageID());
    }

    // Displays all stored messages and recipients
    public static String displayStoredSendersRecipients() {

        if (storedMessages.isEmpty()) {
            return "No stored messages found.";
        }

        String output = "";

        for (Message msg : storedMessages) {
            output += "Recipient: " + msg.getRecipient() + "\n";
            output += "Message: " + msg.getMessage() + "\n\n";
        }

        return output;
    }

    // Finds and displays the longest stored message
    public static String displayLongestStoredMessage() {

        if (storedMessages.isEmpty()) {
            return "No stored messages found.";
        }

        Message longest = storedMessages.get(0);

        for (Message msg : storedMessages) {
            if (msg.getMessage().length() > longest.getMessage().length()) {
                longest = msg;
            }
        }

        return longest.getMessage();
    }

    // Searches for a message using its ID
    public static String searchByMessageID(String id) {

        for (Message msg : storedMessages) {

            if (msg.getMessageID().equals(id)) {

                return "Recipient: "
                        + msg.getRecipient()
                        + "\nMessage: "
                        + msg.getMessage();
            }
        }

        return "Message ID not found.";
    }

    // Searches all messages for a specific recipient
    public static String searchByRecipient(String recipient) {

        String output = "";

        for (Message msg : storedMessages) {

            if (msg.getRecipient().equals(recipient)) {

                output += msg.getMessage() + "\n";
            }
        }

        if (output.equals("")) {
            return "No messages found for this recipient.";
        }

        return output;
    }

    // Deletes a message using the hash value
    public static String deleteByHash(String hash) {

        for (int i = 0; i < storedMessages.size(); i++) {

            Message msg = storedMessages.get(i);

            if (msg.getMessageHash().equals(hash)) {

                String deletedMessage = msg.getMessage();

                storedMessages.remove(i);

                return "Message: \""
                        + deletedMessage
                        + "\" successfully deleted.";
            }
        }

        return "Message hash not found.";
    }

    // Displays a report containing all stored messages
    public static String displayReport() {

        if (storedMessages.isEmpty()) {
            return "No stored messages found.";
        }

        String output = "";

        for (Message msg : storedMessages) {

            output += "Message Hash: "
                    + msg.getMessageHash()
                    + "\n";

            output += "Message ID: "
                    + msg.getMessageID()
                    + "\n";

            output += "Recipient: "
                    + msg.getRecipient()
                    + "\n";

            output += "Message: "
                    + msg.getMessage()
                    + "\n\n";
        }

        return output;
    }

    // Clears all arrays (used for unit testing)
    public static void clearAll() {

        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
    }
}