package com.mycompany.musa_mkansi_poe_part3;

/**
 * Login class handles user registration and login validation.
 */
public class Login {

    // Arrays used to store registered user details
    private String[] usernames = new String[10];
    private String[] passwords = new String[10];
    private String[] cellPhones = new String[10];
    private String[] firstNames = new String[10];
    private String[] lastNames = new String[10];

    // Keeps count of how many users have registered
    private int userCount = 0;

    // Checks that username contains underscore and is no more than 5 characters
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Checks that password has 8 characters, capital letter, number and special character
    public boolean checkPasswordComplexity(String password) {
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapital = true;
            } else if (Character.isDigit(ch)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(ch)) {
                hasSpecial = true;
            }
        }

        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // Checks that cellphone number starts with +27 and is 12 characters long
    public boolean checkCellPhoneNumber(String cellPhone) {
        return cellPhone.startsWith("+27") && cellPhone.length() == 12;
    }

    // Registers a user if all details are valid
    public String registerUser(String firstName, String lastName, String username, String password, String cellPhone) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // Store user details in arrays
        firstNames[userCount] = firstName;
        lastNames[userCount] = lastName;
        usernames[userCount] = username;
        passwords[userCount] = password;
        cellPhones[userCount] = cellPhone;

        userCount++;

        return "User has been registered successfully.";
    }

    // Checks if entered username and password match registered details
    public boolean loginUser(String username, String password) {
        for (int i = 0; i < userCount; i++) {
            if (usernames[i].equals(username) && passwords[i].equals(password)) {
                return true;
            }
        }
        return false;
    }

    // Returns login status message
    public String returnLoginStatus(String username, String password) {
        for (int i = 0; i < userCount; i++) {
            if (usernames[i].equals(username) && passwords[i].equals(password)) {
                return "Welcome " + firstNames[i] + " " + lastNames[i] + ", it is great to see you again.";
            }
        }
        return "Username or password incorrect, please try again.";
    }
}