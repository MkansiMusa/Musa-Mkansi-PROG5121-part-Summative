package com.mycompany.musa_mkansi_poe_part3;

import java.util.Scanner;

/**
 * Main class for the QuickChat application.
 * This class controls registration, login, sending messages and stored message options.
 */
public class Musa_Mkansi_POE_PART3 {

    public static void main(String[] args) {

        // Scanner object used to get input from the user
        Scanner input = new Scanner(System.in);

        // Login object used for registration and login validation
        Login login = new Login();

        // ================= REGISTRATION SECTION =================
        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter cellphone number (example: +27831234567): ");
        String cellPhone = input.nextLine();

        // Register the user and display registration result
        String registrationMessage = login.registerUser(firstName, lastName, username, password, cellPhone);
        System.out.println(registrationMessage);

        // Only continue to login if registration was successful
        if (registrationMessage.equals("User has been registered successfully.")) {

            // ================= LOGIN SECTION =================
            System.out.println("\n===== LOGIN =====");

            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            // Check if login details are correct
            boolean loginSuccess = login.loginUser(loginUsername, loginPassword);

            if (loginSuccess) {

                // Display login success message
                System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
                System.out.println("\nWelcome to QuickChat.");

                // ================= QUICKCHAT MENU SECTION =================
                int choice = 0;
                int totalMessagesSent = 0;

                // Keep showing the menu until user chooses option 4 to quit
                while (choice != 4) {

                    System.out.println("\nChoose an option:");
                    System.out.println("1) Send Messages");
                    System.out.println("2) Show recently sent messages");
                    System.out.println("3) Stored Messages");
                    System.out.println("4) Quit");

                    System.out.print("Enter option: ");
                    choice = input.nextInt();
                    input.nextLine(); // Clears the scanner buffer

                    // ================= SEND MESSAGE SECTION =================
                    if (choice == 1) {

                        System.out.print("How many messages would you like to send? ");
                        int numberOfMessages = input.nextInt();
                        input.nextLine(); // Clears the scanner buffer

                        // Loop according to how many messages the user wants to create
                        for (int i = 1; i <= numberOfMessages; i++) {

                            System.out.println("\n===== MESSAGE " + i + " =====");

                            System.out.print("Enter recipient number: ");
                            String recipient = input.nextLine();

                            System.out.print("Enter message: ");
                            String messageText = input.nextLine();

                            // Create a new Message object
                            Message msg = new Message(i, recipient, messageText);

                            // Validate recipient cellphone number and message length
                            String recipientStatus = msg.checkRecipientCell();
                            String messageStatus = msg.checkMessageLength();

                            System.out.println(recipientStatus);
                            System.out.println(messageStatus);

                            // Only allow message options if recipient and message are valid
                            if (recipientStatus.equals("Cell phone number successfully captured.")
                                    && messageStatus.equals("Message ready to send.")) {

                                System.out.println("\nChoose message option:");
                                System.out.println("1) Send Message");
                                System.out.println("2) Disregard Message");
                                System.out.println("3) Store Message");

                                System.out.print("Enter option: ");
                                int sendOption = input.nextInt();
                                input.nextLine(); // Clears the scanner buffer

                                // Display result of selected message option
                                System.out.println(msg.sentMessage(sendOption));

                                // If message is sent, add it to sentMessages array
                                if (sendOption == 1) {

                                    totalMessagesSent++;
                                    StoredMessages.addSentMessage(msg);

                                    System.out.println("\nMessage Details:");
                                    System.out.println(msg.printMessages());

                                // If message is disregarded, add it to disregardedMessages array
                                } else if (sendOption == 2) {

                                    StoredMessages.addDisregardedMessage(msg);

                                // If message is stored, add it to storedMessages array
                                } else if (sendOption == 3) {

                                    StoredMessages.addStoredMessage(msg);
                                }
                            }
                        }

                        // Display total number of messages successfully sent
                        System.out.println("\nTotal messages sent: " + totalMessagesSent);

                    } else if (choice == 2) {

                        // Display report of sent messages
                        if (StoredMessages.sentMessages.isEmpty()) {
                            System.out.println("No recently sent messages found.");
                        } else {
                            System.out.println("\n===== RECENTLY SENT MESSAGES =====");

                            for (Message sentMsg : StoredMessages.sentMessages) {
                                System.out.println(sentMsg.printMessages());
                                System.out.println();
                            }
                        }

                    } else if (choice == 3) {

                        // ================= STORED MESSAGES MENU =================
                        int storedChoice = 0;

                        // Keep showing stored messages menu until user chooses 7
                        while (storedChoice != 7) {

                            System.out.println("\n===== STORED MESSAGES MENU =====");
                            System.out.println("1) Display stored messages");
                            System.out.println("2) Display longest stored message");
                            System.out.println("3) Search by message ID");
                            System.out.println("4) Search messages by recipient");
                            System.out.println("5) Delete message using hash");
                            System.out.println("6) Display full report");
                            System.out.println("7) Back to main menu");

                            System.out.print("Enter option: ");
                            storedChoice = input.nextInt();
                            input.nextLine(); // Clears the scanner buffer

                            if (storedChoice == 1) {

                                // Display stored messages
                                System.out.println(StoredMessages.displayStoredSendersRecipients());

                            } else if (storedChoice == 2) {

                                // Display the longest stored message
                                System.out.println(StoredMessages.displayLongestStoredMessage());

                            } else if (storedChoice == 3) {

                                // Search for stored message using message ID
                                System.out.print("Enter message ID: ");
                                String id = input.nextLine();

                                System.out.println(StoredMessages.searchByMessageID(id));

                            } else if (storedChoice == 4) {

                                // Search for stored messages using recipient number
                                System.out.print("Enter recipient number: ");
                                String recipientSearch = input.nextLine();

                                System.out.println(StoredMessages.searchByRecipient(recipientSearch));

                            } else if (storedChoice == 5) {

                                // Delete stored message using message hash
                                System.out.print("Enter message hash: ");
                                String hash = input.nextLine();

                                System.out.println(StoredMessages.deleteByHash(hash));

                            } else if (storedChoice == 6) {

                                // Display full stored messages report
                                System.out.println(StoredMessages.displayReport());

                            } else if (storedChoice == 7) {

                                // Return to main menu
                                System.out.println("Returning to main menu.");

                            } else {

                                // Invalid stored menu option
                                System.out.println("Invalid option selected.");
                            }
                        }

                    } else if (choice == 4) {

                        // Exit program
                        System.out.println("Goodbye.");

                    } else {

                        // Invalid main menu option
                        System.out.println("Invalid option selected.");
                    }
                }

            } else {

                // Login failed
                System.out.println("Username or password incorrect, please try again.");
            }
        }

        // Close Scanner object
        input.close();
    }
}